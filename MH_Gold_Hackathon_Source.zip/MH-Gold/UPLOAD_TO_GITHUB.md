# Upload MH Gold to GitHub

1. Download and extract `MH_Gold_Hackathon_Source.zip`.
2. Open a terminal inside the extracted **MH-Gold** folder.
3. On GitHub, create a new **empty** repository (for example, `mh-gold`). Do not initialize it with another README.
4. Run:

```sh
git init
git add .
git commit -m "MH Gold hackathon demo"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mh-gold.git
git push -u origin main
```

Replace `YOUR_USERNAME` and the repository name with your actual repository URL. GitHub may ask you to authenticate.

If the repository already has code, clone it first and copy these files into it before committing; do not force-push over existing work.

Alternatively use GitHub's **Add file → Upload files** and upload the extracted contents, not the ZIP. Include the hidden `.openai` directory and `.gitignore`; terminal Git is more reliable for hidden files.

`JUDGES_README.md` contains run instructions and a walkthrough. The source ZIP includes the no-sign-in demo, Healthy Living, logo, backend, migrations and tests. It excludes `.git` history, credentials, resident data, local databases, dependencies and generated builds.

Submit your GitHub repository URL, the public app URL below, and your separately recorded Google Drive demo-video link:

https://mountain-house-together.enjoyableoasis.chatgpt.site/

The repository must be public or accessible to judges. Do not claim live AI is enabled: the demo labels local sample matching, and the live AI integration requires setup as described in the judges' guide.
