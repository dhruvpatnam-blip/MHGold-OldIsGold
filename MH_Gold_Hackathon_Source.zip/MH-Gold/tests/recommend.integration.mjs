import assert from 'node:assert/strict';
globalThis.__testEnv={};globalThis.__testHeaders=new Headers();
const {POST}=await import('../app/api/recommend/route.ts');
const prefs={interests:['Social'],pace:'Relaxed',setting:'Either',consent:true};
async function call(body=prefs,origin='https://app.test'){return POST(new Request('https://app.test/api/recommend',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)}))}
assert.equal((await call()).status,401);
globalThis.__testHeaders=new Headers({'oai-authenticated-user-id':'synthetic','oai-authenticated-user-email':'test@example.invalid'});
assert.equal((await call(prefs,'https://other.test')).status,403);
assert.equal((await call({...prefs,consent:false})).status,400);
assert.equal((await call({...prefs,interests:['invented']})).status,400);
const r=await call();assert.equal(r.status,503);assert.match((await r.json()).error,/not connected/);
console.log('Recommendation authentication, consent, input and disconnected-state checks passed. No external requests.');
