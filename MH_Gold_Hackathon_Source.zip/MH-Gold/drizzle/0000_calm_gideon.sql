CREATE TABLE `blocks` (
	`user` text NOT NULL,
	`blocked` text NOT NULL,
	PRIMARY KEY(`user`, `blocked`)
);
--> statement-breakpoint
CREATE TABLE `games` (
	`id` text PRIMARY KEY NOT NULL,
	`x` text NOT NULL,
	`o` text,
	`board` text NOT NULL,
	`turn` text DEFAULT 'X' NOT NULL,
	`winner` text,
	`version` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `gatherings` (
	`id` text PRIMARY KEY NOT NULL,
	`host` text NOT NULL,
	`title` text NOT NULL,
	`category` text NOT NULL,
	`date` text NOT NULL,
	`time` text NOT NULL,
	`venue` text NOT NULL,
	`description` text NOT NULL,
	`capacity` integer NOT NULL,
	`status` text DEFAULT 'open' NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` text PRIMARY KEY NOT NULL,
	`gathering` text NOT NULL,
	`user` text NOT NULL,
	`body` text NOT NULL,
	`removed` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`name` text NOT NULL,
	`street` text NOT NULL,
	`unit` text DEFAULT '' NOT NULL,
	`zip` text NOT NULL,
	`age55` integer NOT NULL,
	`interests` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`boundary` text DEFAULT 'unknown' NOT NULL,
	`boundary_note` text NOT NULL,
	`review_note` text,
	`reviewed_by` text,
	`reviewed_at` text,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `reports` (
	`id` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`target` text NOT NULL,
	`reason` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rsvps` (
	`gathering` text NOT NULL,
	`user` text NOT NULL,
	PRIMARY KEY(`gathering`, `user`)
);
