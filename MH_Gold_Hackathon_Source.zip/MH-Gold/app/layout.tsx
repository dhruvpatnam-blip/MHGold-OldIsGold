import type {Metadata} from 'next';import './globals.css';
export const metadata:Metadata={title:'MH Gold - Old is Gold',icons:{icon:'/favicon.svg',shortcut:'/favicon.svg'},description:'A reviewed 55+ Mountain House resident community for companionship, gatherings, senior activities and games.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
