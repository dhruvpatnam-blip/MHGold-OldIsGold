import CommunityApp from './community-app';
export const dynamic='force-dynamic';
export default function Page(){return <CommunityApp/>}
