# Quick start for hackathon judges

Open the public demo without signing in: https://mountain-house-together.enjoyableoasis.chatgpt.site/

For local setup, demo walkthrough and AI limitations, read [JUDGES_README.md](JUDGES_README.md). To upload this source, read [UPLOAD_TO_GITHUB.md](UPLOAD_TO_GITHUB.md).

# MH Gold - Old is Gold

A 55+ Mountain House resident community pilot. Independent of city government.

## Implemented

- ChatGPT sign-in through the hosting platform. The server uses trusted platform identity headers.
- Private application with street address, unit, ZIP, self-declared 55+ eligibility, interests, and explicit privacy/geocoder consent.
- Geographic checks through the U.S. Census Geocoder. Unknown/outside results do not grant membership. Moderators may document a separate exact-parcel check against the official city GIS map when automated matching is incomplete.
- Separate moderator review of evidence that the person actually lives at the address. Approval requires inside-city geography, age eligibility and the moderator's explicit evidence confirmation.
- Member gathering creation, atomic bounded RSVPs, cancellation/leave controls, participant-only discussions and member plans.
- Reports, hidden-member filtering, message removal and membership suspension.
- D1-backed two-player tic-tac-toe with turn validation and optimistic version checks. About-five-second polling; a separate same-device practice game works without member access.
- Dated official senior-event listings, category filters, calendar-file downloads and a nearby Tracy program discovery link.
- Responsive layout, larger-text option, labeled controls and keyboard focus management in dialogs.

## Current release boundaries

This Site remains private for owner review. A broader enrollment audience must be explicitly enabled before residents can apply. Application-layer controls continue to require reviewed membership even if a public landing page is enabled later.

A geographic match proves neither residency nor age. Age is self-declared. Residency evidence review is performed separately by the moderator; no identity documents are uploaded here. This is not a background-check service.

City events are a timestamped snapshot in `data/senior-events.json`. Run `node scripts/refresh-events.mjs` and republish to refresh it. Near-city entertainment is a clearly labeled discovery link, not a live nearby-events aggregator. Email/push notifications and automatic evidence verification are not enabled.

Member APIs and two-player behavior have been tested with synthetic identities and an in-memory SQLite database. That does not prove the platform sign-in, production geocoding or a complete two-person hosted journey. Those need a controlled pilot with approved test participants.

## Privacy and moderation

The private address is returned only to the owner-configured moderator. Ordinary member profiles, gatherings, discussions and game lists exclude street, unit, ZIP and other members' email. Applicants consent before the street and ZIP are sent to the Census service. Unit is not sent to Census. Hosting/geography providers may keep operational logs. No precise coordinates, identity images or dates of birth are collected.

`ADMIN_EMAIL` is a server-side hosting secret matching the project owner. Never put it or other credentials in browser code or Git. Reviewers should record references without document numbers, keep evidence outside group chat, and establish an operational evidence-handling and retention process before public enrollment. The included write limiter is best-effort per isolate, not a durable abuse-control guarantee.

## Development and validation

Requires the starter's supported Node version (22.13+); the test adapter uses Node 24's built-in SQLite.

- `npm run dev`
- `node node_modules/typescript/bin/tsc --noEmit`
- `node --test tests/rules.test.mjs`
- `node --experimental-loader ./tests/loader.mjs tests/api.integration.mjs`
- Build with the Sites `build-site.mjs` helper, preserving the supplied Vite/Worker integration.

`tests/loader.mjs` mocks platform headers and D1 only in the local integration test process. It is not imported by the application. Test identities and review decisions never enter the hosted database.

The tracked Drizzle migration is schema-only. Local preview and hosted D1 are separate; publishing applies hosted migrations through the supported workflow. Do not replay applied migrations or alter them.

## Sources

- https://www.mountainhouseca.gov/213/Prime-Time-Seniors
- https://www.mountainhouseca.gov/common/modules/iCalendar/iCalendar.aspx?catID=26&feed=calendar
- https://www.mountainhouseca.gov/407/Interactive-GIS-Map
- https://geocoding.geo.census.gov/geocoder/Geocoding_Services_API.html
- https://www.cityoftracy.org/Departments/Parks-Recreation-Community-Services/Lolly-Hansen-Senior-Center

## Healthy Living and activity recommendations

Healthy Living offers curated NIH wellness topics, a browser-only question guide, and gathering templates that prefill the existing reviewed-member creation form. It does not diagnose, prescribe, provide personal care, or post questions to group discussions.

The activity recommender uses the OpenAI Responses API. Configure `OPENAI_API_KEY` as a server-side secret and optionally `OPENAI_MODEL` (default `gpt-4.1-mini`). Never commit keys. For ChatGPT Sites, enable the OpenAI Developers plugin and complete its API-key setup before adding the runtime secret. Until configured, the UI explicitly reports that AI is not connected and offers the regular activity browser. Do not present the disconnected state as working AI.

After explicit consent, only selected activity interests, pace and setting are sent along with dated official city listings. Addresses, emails, health details and private member gatherings are excluded. API requests use `store:false`; provider operational retention policies still apply. The server validates inputs, rate-limits requests per signed-in user per isolate, limits candidate/output counts, and resolves model-selected IDs against the original listing set. It never accepts invented URLs or event details from the model. Snapshot listings must still be confirmed with organizers. A durable rate limiter and usage budget should be configured for a broader launch.

Verification: check a matched and unmatched wellness question; use a healthy-habits template as an approved member; test the AI configuration/error states. Once the key is connected, test live matching and unknown pace/setting with actual listings before claiming the AI feature is validated.

## No-sign-in public demo

The default URL opens a clearly labeled fictional demo. It uses browser memory only: sample profiles, sample gatherings, local RSVPs, local participant messages, healthy-habits creation and a simple computer tic-tac-toe opponent. Reload or Reset demo clears changes. Demo mode never calls member APIs or changes resident records. No address is collected. Activity matching in demo is explicitly labeled sample interest matching, not working AI. Live protected membership remains available with `?mode=live`; changing that URL does not grant backend access.
